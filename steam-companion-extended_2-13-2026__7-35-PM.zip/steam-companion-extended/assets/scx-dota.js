document.addEventListener("DOMContentLoaded", function () {

    /* ================= ACCORDION ================= */
    const head = document.querySelector(".scx-dota-head");
    const body = document.querySelector(".scx-dota-content");
    const toggle = document.querySelector(".scx-dota-toggle");

    if (head && body && toggle) {
        head.addEventListener("click", function () {
            const open = body.style.display === "block";
            body.style.display = open ? "none" : "block";
            toggle.textContent = open ? "+" : "–";
        });
    }

    /* ================= CUSTOM SELECT (ALL TYPES) ================= */
    document.querySelectorAll(".scx-select, .scx-form-select").forEach(function (select) {
        const trigger = select.querySelector(".scx-select-trigger");
        const options = select.querySelector(".scx-select-options");
        const hidden = select.querySelector("input[type=hidden]");

        if (!trigger || !options || !hidden) return;

        trigger.addEventListener("click", function (e) {
            e.stopPropagation();

            // Close other open selects
            document.querySelectorAll(".scx-select-options").forEach(function (o) {
                if (o !== options) o.style.display = "none";
            });

            options.style.display = (options.style.display === "block") ? "none" : "block";
        });

        options.querySelectorAll(".scx-option").forEach(function (opt) {
            opt.addEventListener("click", function (e) {
                e.stopPropagation();
                trigger.textContent = opt.textContent;
                hidden.value = opt.dataset.value;
                options.style.display = "none";
            });
        });
    });

    document.addEventListener("click", function () {
        document.querySelectorAll(".scx-select-options").forEach(function (o) {
            o.style.display = "none";
        });
    });

    /* ================= LISTINGS FILTER (AJAX) ================= */
    document.querySelectorAll('.scx-listings-filter').forEach(function (form) {
        const container = form.closest('.scx-listings-wrap');
        const results = container ? container.querySelector('.scx-listings-results') : null;

        if (!container || !results || typeof scx_listing_filter === 'undefined') return;

        function serializeFilters() {
            const data = {};
            form.querySelectorAll('input').forEach(function (input) {
                if (!input.name) return;
                if (input.type === 'checkbox') {
                    data[input.name] = input.checked ? (input.value || '1') : '';
                } else {
                    data[input.name] = input.value;
                }
            });
            return data;
        }

        function getShortcodeAtts() {
            const atts = container.dataset.atts;
            if (!atts) return {};
            try {
                return JSON.parse(atts);
            } catch (e) {
                return {};
            }
        }

        function applyFilters() {
            const payload = new FormData();
            payload.append('action', 'scx_filter_listings');
            payload.append('nonce', scx_listing_filter.nonce);

            const filters = serializeFilters();
            Object.keys(filters).forEach(function (key) {
                payload.append(`filters[${key}]`, filters[key]);
            });

            const atts = getShortcodeAtts();
            Object.keys(atts).forEach(function (key) {
                payload.append(`atts[${key}]`, atts[key]);
            });

            container.classList.add('scx-filter-loading');
            fetch(scx_listing_filter.ajax_url, {
                method: 'POST',
                body: payload
            })
                .then(function (response) { return response.json(); })
                .then(function (response) {
                    if (response.success && response.data && typeof response.data.html === 'string') {
                        results.innerHTML = response.data.html;
                    }
                })
                .finally(function () {
                    container.classList.remove('scx-filter-loading');
                });
        }

        form.addEventListener('submit', function (e) {
            e.preventDefault();
            applyFilters();
        });

        const resetBtn = form.querySelector('.scx-btn-reset');
        if (resetBtn) {
            resetBtn.addEventListener('click', function () {
                form.querySelectorAll('input').forEach(function (input) {
                    if (input.type === 'checkbox') {
                        input.checked = false;
                    } else if (input.type === 'hidden') {
                        input.value = '';
                        const select = input.closest('.scx-select');
                        if (!select) return;
                        const trigger = select.querySelector('.scx-select-trigger');
                        const placeholderOption = select.querySelector('.scx-option[data-value=""]');
                        if (trigger && placeholderOption) {
                            trigger.textContent = placeholderOption.textContent;
                        }
                    } else {
                        input.value = '';
                    }
                });

                applyFilters();
            });
        }
    });

    /* ================= STARS ================= */
    document.querySelectorAll(".scx-stars").forEach(function (box) {
        const stars = box.querySelectorAll("span");
        const input = box.nextElementSibling;

        if (!input) return;

        stars.forEach(function (star) {
            star.addEventListener("click", function () {
                const value = parseInt(star.dataset.star, 10);
                input.value = value;

                stars.forEach(function (s) {
                    s.classList.toggle("active", parseInt(s.dataset.star, 10) <= value);
                });
            });
        });
    });

    /* ================= MEDALS ================= */
    document.querySelectorAll('.scx-medal-card').forEach(function (card) {
        const medals = card.querySelectorAll('.scx-medal');
        const input = card.querySelector('input[name="dota_medal"]');

        medals.forEach(function (medal) {
            medal.addEventListener('click', function () {
                medals.forEach(function (m) { m.classList.remove('active'); });
                medal.classList.add('active');
                if (input) input.value = medal.dataset.value;
            });
        });
    });

	    /* ================= DOTA INPUT LIMITS (NOT REQUIRED) ================= */

    function limitDigitsWithMessage(input, maxDigits, label) {
        const error = document.createElement("small");
        error.style.color = "#FF0000";
        error.style.display = "none";
        error.style.marginTop = "4px";
        error.style.fontWeight = "900";
        error.textContent = `${label} حداکثر ${maxDigits} رقم مجاز است`;

        input.parentNode.appendChild(error);

        input.addEventListener("input", function () {
            // فقط عدد
            this.value = this.value.replace(/\D/g, "");

            // خالی باشه → مشکلی نداره
            if (this.value === "") {
                error.style.display = "none";
                return;
            }

            // محدودیت رقم
            if (this.value.length > maxDigits) {
                this.value = this.value.slice(0, maxDigits);
                error.style.display = "block";
            } else {
                error.style.display = "none";
            }
        });
    }

    const mmrInput = document.querySelector('input[name="dota_mmr"]');
    const behaviorInput = document.querySelector('input[name="dota_behavior"]');
    const levelInput = document.querySelector('input[name="dota_level"]');
    const shardsInput = document.querySelector('input[name="dota_shards"]');

    if (mmrInput) limitDigitsWithMessage(mmrInput, 5, "MMR");
    if (behaviorInput) limitDigitsWithMessage(behaviorInput, 5, "Behavior Score");
    if (levelInput) limitDigitsWithMessage(levelInput, 4, "Dota Level");
    if (shardsInput) limitDigitsWithMessage(shardsInput, 7, "Shards");


    /* ================= ACCOUNT FORM ================= */

    /* MULTI IMAGE UPLOAD (MAX 10) */
    const uploadBtn = document.querySelector(".scx-upload-btn");
    const uploadInput = document.getElementById("scx-upload-input");
    const previews = document.querySelector(".scx-upload-previews");

    if (uploadBtn && uploadInput && previews) {

        uploadBtn.addEventListener("click", function () {
            uploadInput.click();
        });

        uploadInput.addEventListener("change", function () {
            const files = Array.from(uploadInput.files).slice(0, 10);
            previews.innerHTML = "";

            files.forEach(function (file) {
                if (!file.type.startsWith("image/")) return;

                const reader = new FileReader();
                reader.onload = function (e) {
                    const img = document.createElement("img");
                    img.src = e.target.result;
                    previews.appendChild(img);
                };
                reader.readAsDataURL(file);
            });

            if (uploadInput.files.length > 10) {
                alert("حداکثر 10 تصویر مجاز است.");
            }
        });
    }

});





/* ================= ACCOUNT FORM ================= */

const submitBtn = document.querySelector(".scx-submit-btn");
const accountForm = document.querySelector(".scx-account-form");
const successMessageKey = "scxAccountSubmissionSuccess";
let isSubmitting = false;

function showAccountSuccessMessage() {
    if (!accountForm) return;

    const successBox = document.createElement('div');
    successBox.className = 'scx-form-success-message';
    successBox.textContent = 'آکانت با موفقیت ارسال شد. بعد از بررسی منتشر خواهد شد.';
    successBox.style.cssText = 'margin-bottom:12px;padding:10px 12px;border-radius:10px;background:#133b1f;color:#8df3a9;font-weight:700;';

    accountForm.insertBefore(successBox, accountForm.firstChild);
}

if (window.sessionStorage && sessionStorage.getItem(successMessageKey) === '1') {
    sessionStorage.removeItem(successMessageKey);
    showAccountSuccessMessage();
}

if (submitBtn) {
    submitBtn.addEventListener("click", function () {
		if (isSubmitting) return;
        isSubmitting = true;
        submitBtn.disabled = true;
        submitBtn.textContent = 'در حال ارسال...';

        const formData = new FormData();

        // Basic form fields
        document.querySelectorAll(".scx-account-form input, .scx-account-form textarea").forEach(function (field) {
            if (field.name) {
                formData.append(field.name, field.value);
            }
        });

        // Steam profile data (from rendered UI)
        formData.append("steam_avatar", document.querySelector(".scx-avatar-wrap img")?.src || "");
        formData.append("steam_name", document.querySelector(".scx-header-info h2")?.innerText || "");
        formData.append("steam_level", document.querySelector(".scx-badge.level")?.innerText.replace("Lv", "").trim() || "");
        formData.append("steam_profile_url", document.querySelector(".scx-profile-link")?.href || "");

        // Ban data
        formData.append("ban_community", document.querySelector(".scx-ban-item:nth-child(1)")?.classList.contains("bad") ? "1" : "0");
        formData.append("ban_trade", document.querySelector(".scx-ban-item:nth-child(2)")?.classList.contains("bad") ? "1" : "0");
        formData.append("ban_game", document.querySelector(".scx-ban-item:nth-child(3)")?.classList.contains("bad") ? "1" : "0");
        formData.append("ban_vac", document.querySelector(".scx-ban-item:nth-child(4)")?.classList.contains("bad") ? "1" : "0");

        // Stats
        document.querySelectorAll(".scx-stat").forEach(function (stat) {
            const label = stat.querySelector("span")?.innerText;
            const value = stat.querySelector("strong")?.innerText;
            if (label && value) {
                formData.append(label.toLowerCase().replace(/\s+/g, "_"), value);
            }
        });

        // Game library
        const games = [];
        document.querySelectorAll(".scx-game-card").forEach(function (card) {
            games.push({
                name: card.querySelector(".scx-game-title")?.innerText || "",
                hours: card.querySelector(".scx-game-hours")?.innerText || "",
                price: card.querySelector(".scx-game-price, .scx-game-free")?.innerText || "",
                image: card.querySelector("img")?.src || ""
            });
        });
        formData.append("games_library", JSON.stringify(games));

        // Dota fields
        document.querySelectorAll(".scx-dota-content input").forEach(function (field) {
            if (field.name) {
                formData.append(field.name, field.value);
            }
        });

        // Uploaded images
        const uploadInput = document.getElementById("scx-upload-input");
        if (uploadInput && uploadInput.files.length) {
            Array.from(uploadInput.files).forEach(function (file) {
                formData.append("account_images[]", file);
            });
        }

        // AJAX meta
        formData.append("action", "scx_submit_account");
        formData.append("nonce", scx_ajax.nonce);

        fetch(scx_ajax.ajax_url, {
            method: "POST",
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
            if (window.sessionStorage) {
                    sessionStorage.setItem(successMessageKey, '1');
                }
                window.location.reload();
            } else {
				isSubmitting = false;
                submitBtn.disabled = false;
                submitBtn.textContent = 'ارسال آکانت';
                alert("خطا: " + data.data);
            }
        })
                .catch(() => {
            isSubmitting = false;
            submitBtn.disabled = false;
            submitBtn.textContent = 'ارسال آکانت';
            alert("خطا در ارسال فرم");
        });
    });
}



/* برای اسلاید عکس ها در صفحه محصول تکی  */
jQuery(function($){

let slides = $('.scx-pro-slide');
let thumbs = $('.scx-thumb');
let index = 0;

/* SHOW */
function showSlide(i){
    slides.removeClass('active').eq(i).addClass('active');
    thumbs.removeClass('active').eq(i).addClass('active');
    index = i;
}

/* ARROWS */
$('.scx-pro-next').click(function(){
    let i = index+1;
    if(i>=slides.length) i=0;
    showSlide(i);
});

$('.scx-pro-prev').click(function(){
    let i = index-1;
    if(i<0) i=slides.length-1;
    showSlide(i);
});

/* THUMB CLICK */
thumbs.click(function(){
    showSlide($(this).data('index'));
});

/* LIGHTBOX */
$('.scx-pro-slide img').click(function(){
    $('.scx-lightbox-img').attr('src', $(this).data('full'));
    $('.scx-pro-lightbox').fadeIn(200);
});

$('.scx-pro-lightbox, .scx-lightbox-close').click(function(e){
    if(e.target !== this) return;
    $('.scx-pro-lightbox').fadeOut(200);
});

/* KEYBOARD */
$(document).keydown(function(e){
    if(e.key === 'ArrowRight') $('.scx-pro-next').click();
    if(e.key === 'ArrowLeft') $('.scx-pro-prev').click();
    if(e.key === 'Escape') $('.scx-pro-lightbox').fadeOut(200);
});

/* SWIPE */
let startX=0;

$('.scx-pro-main').on('touchstart', e=>{
    startX = e.originalEvent.touches[0].clientX;
});

$('.scx-pro-main').on('touchend', e=>{
    let endX = e.originalEvent.changedTouches[0].clientX;
    if(startX-endX>50) $('.scx-pro-next').click();
    if(endX-startX>50) $('.scx-pro-prev').click();
});

});
