<?php
if (!defined('ABSPATH')) {
    exit;
}

function scp_public_profile_get_level_class($steam_level) {
    $steam_level = (int) $steam_level;

    if ($steam_level >= 101) {
        return 'scp-level-platinum';
    }

    if ($steam_level >= 61) {
        return 'scp-level-gold';
    }

    if ($steam_level >= 31) {
        return 'scp-level-silver';
    }

    if ($steam_level >= 11) {
        return 'scp-level-bronze';
    }

    return 'scp-level-basic';
}

function scp_public_profile_render_games_section($title, $games, $empty_text, $limit = 0) {
    $games = is_array($games) ? $games : [];
    if ($limit > 0) {
        $games = array_slice($games, 0, $limit);
    }

    ob_start();
    ?>
    <div class="scp-section-header">
        <h3 class="scp-section-title"><?php echo esc_html($title); ?></h3>
    </div>

    <div class="scp-games-grid">
        <?php if (!empty($games)) : ?>
            <?php foreach ($games as $game) :
                $appid = isset($game['appid']) ? (int) $game['appid'] : 0;
                $name = isset($game['name']) ? $game['name'] : '';
                $playtime = isset($game['playtime_forever']) ? (float) $game['playtime_forever'] : 0;
                ?>
                <div class="scp-game-card">
                    <img src="https://cdn.cloudflare.steamstatic.com/steam/apps/<?php echo esc_attr($appid); ?>/header.jpg" alt="<?php echo esc_attr($name); ?>">
                    <div class="scp-game-info">
                        <strong><?php echo esc_html($name); ?></strong>
                        <div class="scp-playtime-badge"><?php echo esc_html(round($playtime / 60, 1)); ?> ساعت بازی</div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else : ?>
            <div class="scp-empty-state"><?php echo esc_html($empty_text); ?></div>
        <?php endif; ?>
    </div>
    <?php

    return ob_get_clean();
}

function scp_public_profile_tab_content($steam_id, $tab) {
    $steam_id = sanitize_text_field((string) $steam_id);
    $tab = sanitize_key((string) $tab);

    if (!$steam_id) {
        return '<div class="scp-empty-state">شناسه استیم معتبر نیست.</div>';
    }

    if ($tab === 'items') {
        return do_shortcode('[for-sale-user-item]');
    }

    if ($tab === 'accounts') {
        return do_shortcode('[for-sale-user-account]');
    }

    $recent_games = scp_get_recent_games($steam_id);
    $owned_games = scp_get_owned_games($steam_id);

    if (!empty($recent_games)) {
        usort($recent_games, function ($a, $b) {
            return ($b['playtime_forever'] ?? 0) <=> ($a['playtime_forever'] ?? 0);
        });
    }

    if (!empty($owned_games)) {
        usort($owned_games, function ($a, $b) {
            return ($b['playtime_forever'] ?? 0) <=> ($a['playtime_forever'] ?? 0);
        });
    }

    return scp_public_profile_render_games_section('بازی اخیراً پلی شده', $recent_games, 'هیچ بازی اخیری پیدا نشد')
        . scp_public_profile_render_games_section('بازی‌هایی که این کاربر تجربه کرده', $owned_games, 'هیچ بازی‌ای یافت نشد', 24);
}

function scp_public_profile_render_tabs($steam_id) {
    $steam_id = sanitize_text_field((string) $steam_id);
    ob_start();
    ?>
    <section class="scp-public-tabs" data-steam-id="<?php echo esc_attr($steam_id); ?>">
        <div class="scp-public-tabs-nav" role="tablist" aria-label="Public profile tabs">
            <button type="button" class="scp-public-tab-btn is-active" data-tab="info">اطلاعات کاربر</button>
            <button type="button" class="scp-public-tab-btn" data-tab="items">آیتم های برای فروش</button>
            <button type="button" class="scp-public-tab-btn" data-tab="accounts">آکانت برای فروش این کاربر</button>
        </div>

        <div class="scp-public-tabs-content" id="scp-public-tabs-content">
            <?php echo scp_public_profile_tab_content($steam_id, 'info'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        </div>
    </section>
    <?php

    return ob_get_clean();
}

add_action('wp_ajax_scp_load_public_profile_tab', 'scp_ajax_load_public_profile_tab');
add_action('wp_ajax_nopriv_scp_load_public_profile_tab', 'scp_ajax_load_public_profile_tab');
function scp_ajax_load_public_profile_tab() {
    check_ajax_referer('scp-public-profile-tabs', 'nonce');

    $steam_id = isset($_POST['steam_id']) ? sanitize_text_field(wp_unslash($_POST['steam_id'])) : '';
    $tab = isset($_POST['tab']) ? sanitize_key(wp_unslash($_POST['tab'])) : 'info';

    wp_send_json_success([
        'html' => scp_public_profile_tab_content($steam_id, $tab),
    ]);
}

add_action('wp_enqueue_scripts', function () {
    if (!get_query_var('scp_steam_user')) {
        return;
    }

    wp_enqueue_style(
        'scp-public-profile-tabs',
        SCP_PLUGIN_URL . 'assets/css/public-profile-tabs.css',
        ['scp-style'],
        SCP_VERSION
    );

    wp_enqueue_script(
        'scp-public-profile-tabs',
        SCP_PLUGIN_URL . 'assets/js/public-profile-tabs.js',
        [],
        SCP_VERSION,
        true
    );

    wp_localize_script('scp-public-profile-tabs', 'scpPublicTabs', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('scp-public-profile-tabs'),
    ]);
});
