<?php
if (!defined('ABSPATH')) {
    exit;
}

function scp_chat_table_rooms() {
    global $wpdb;
    return $wpdb->prefix . 'scp_chat_rooms';
}

function scp_chat_table_messages() {
    global $wpdb;
    return $wpdb->prefix . 'scp_chat_messages';
}

function scp_chat_install_tables() {
    global $wpdb;

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $charset_collate = $wpdb->get_charset_collate();
    $rooms_table = scp_chat_table_rooms();
    $messages_table = scp_chat_table_messages();

    $sql_rooms = "CREATE TABLE {$rooms_table} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_one BIGINT UNSIGNED NOT NULL,
        user_two BIGINT UNSIGNED NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY user_pair (user_one, user_two),
        KEY updated_at (updated_at)
    ) {$charset_collate};";

    $sql_messages = "CREATE TABLE {$messages_table} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        room_id BIGINT UNSIGNED NOT NULL,
        sender_id BIGINT UNSIGNED NOT NULL,
        message TEXT NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY room_id (room_id),
        KEY room_message (room_id, id)
    ) {$charset_collate};";

    dbDelta($sql_rooms);
    dbDelta($sql_messages);
}

function scp_chat_normalize_pair($user_a, $user_b) {
    $user_a = (int) $user_a;
    $user_b = (int) $user_b;

    return [$user_a < $user_b ? $user_a : $user_b, $user_a < $user_b ? $user_b : $user_a];
}

function scp_chat_get_or_create_room($user_a, $user_b) {
    global $wpdb;

    list($user_one, $user_two) = scp_chat_normalize_pair($user_a, $user_b);

    if ($user_one <= 0 || $user_two <= 0 || $user_one === $user_two) {
        return 0;
    }

    $rooms_table = scp_chat_table_rooms();

    $room_id = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$rooms_table} WHERE user_one = %d AND user_two = %d",
        $user_one,
        $user_two
    ));

    if ($room_id > 0) {
        return $room_id;
    }

    $inserted = $wpdb->insert(
        $rooms_table,
        [
            'user_one' => $user_one,
            'user_two' => $user_two,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        ],
        ['%d', '%d', '%s', '%s']
    );

    if ($inserted) {
        return (int) $wpdb->insert_id;
    }

    return (int) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$rooms_table} WHERE user_one = %d AND user_two = %d",
        $user_one,
        $user_two
    ));
}

function scp_chat_get_room($room_id) {
    global $wpdb;
    $rooms_table = scp_chat_table_rooms();

    return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$rooms_table} WHERE id = %d", (int) $room_id));
}

function scp_chat_user_in_room($room, $user_id) {
    $user_id = (int) $user_id;
    if (!$room || $user_id <= 0) {
        return false;
    }

    return ((int) $room->user_one === $user_id || (int) $room->user_two === $user_id);
}

function scp_chat_get_user_payload($user_id) {
    $user = get_userdata($user_id);
    if (!$user) {
        return null;
    }

    $steam_id = (string) get_user_meta($user_id, 'steam_id', true);

    return [
        'id' => (int) $user_id,
        'name' => $user->display_name,
        'avatar' => scp_get_user_avatar_url($user_id, 64),
        'public_profile_url' => $steam_id ? home_url('/steam-user/' . $steam_id) : '',
    ];
}

function scp_chat_get_messages($room_id, $limit = 50, $after_id = 0) {
    global $wpdb;
    $messages_table = scp_chat_table_messages();

    $limit = max(1, min(100, (int) $limit));
    $after_id = (int) $after_id;

    if ($after_id > 0) {
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$messages_table} WHERE room_id = %d AND id > %d ORDER BY id ASC LIMIT %d",
            (int) $room_id,
            $after_id,
            $limit
        ));
    } else {
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$messages_table} WHERE room_id = %d ORDER BY id DESC LIMIT %d",
            (int) $room_id,
            $limit
        ));
        $results = array_reverse($results);
    }

    $messages = [];
    foreach ($results as $row) {
        $sender = scp_chat_get_user_payload((int) $row->sender_id);
        if (!$sender) {
            continue;
        }
        $messages[] = [
            'id' => (int) $row->id,
            'room_id' => (int) $row->room_id,
            'sender_id' => (int) $row->sender_id,
            'message' => $row->message,
            'created_at' => mysql2date('c', $row->created_at),
            'sender' => $sender,
        ];
    }

    return $messages;
}

function scp_chat_nonce_or_fail() {
    if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'scp-ajax')) {
        wp_send_json_error(['message' => 'invalid_nonce'], 400);
    }
}

add_action('wp_ajax_scp_chat_open_room', function () {
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'unauthorized'], 401);
    }
    scp_chat_nonce_or_fail();

    $current_user_id = get_current_user_id();
    $target_user_id = isset($_POST['target_user_id']) ? (int) $_POST['target_user_id'] : 0;

    if ($target_user_id <= 0 || $target_user_id === $current_user_id || !get_userdata($target_user_id)) {
        wp_send_json_error(['message' => 'invalid_target'], 400);
    }

    $room_id = scp_chat_get_or_create_room($current_user_id, $target_user_id);
    if ($room_id <= 0) {
        wp_send_json_error(['message' => 'room_create_failed'], 500);
    }

    wp_send_json_success([
        'room_id' => $room_id,
        'participants' => [
            scp_chat_get_user_payload($current_user_id),
            scp_chat_get_user_payload($target_user_id),
        ],
        'messages' => scp_chat_get_messages($room_id, 50),
    ]);
});

add_action('wp_ajax_scp_chat_send_message', function () {
    global $wpdb;

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'unauthorized'], 401);
    }
    scp_chat_nonce_or_fail();

    $current_user_id = get_current_user_id();
    $room_id = isset($_POST['room_id']) ? (int) $_POST['room_id'] : 0;
    $raw_message = isset($_POST['message']) ? wp_unslash($_POST['message']) : '';
    $message = trim(sanitize_textarea_field($raw_message));

    if ($room_id <= 0 || $message === '') {
        wp_send_json_error(['message' => 'invalid_payload'], 400);
    }

    if (mb_strlen($message) > 1000) {
        wp_send_json_error(['message' => 'message_too_long'], 400);
    }

    $room = scp_chat_get_room($room_id);
    if (!scp_chat_user_in_room($room, $current_user_id)) {
        wp_send_json_error(['message' => 'forbidden'], 403);
    }

    $messages_table = scp_chat_table_messages();
    $rooms_table = scp_chat_table_rooms();

    $inserted = $wpdb->insert(
        $messages_table,
        [
            'room_id' => $room_id,
            'sender_id' => $current_user_id,
            'message' => $message,
            'created_at' => current_time('mysql'),
        ],
        ['%d', '%d', '%s', '%s']
    );

    if (!$inserted) {
        wp_send_json_error(['message' => 'send_failed'], 500);
    }

    $wpdb->update(
        $rooms_table,
        ['updated_at' => current_time('mysql')],
        ['id' => $room_id],
        ['%s'],
        ['%d']
    );

    $message_id = (int) $wpdb->insert_id;
    $messages = scp_chat_get_messages($room_id, 1, $message_id - 1);

    wp_send_json_success([
        'message' => !empty($messages) ? $messages[0] : null,
    ]);
});

add_action('wp_ajax_scp_chat_fetch_messages', function () {
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'unauthorized'], 401);
    }
    scp_chat_nonce_or_fail();

    $current_user_id = get_current_user_id();
    $room_id = isset($_POST['room_id']) ? (int) $_POST['room_id'] : 0;
    $after_id = isset($_POST['after_id']) ? (int) $_POST['after_id'] : 0;

    $room = scp_chat_get_room($room_id);
    if (!scp_chat_user_in_room($room, $current_user_id)) {
        wp_send_json_error(['message' => 'forbidden'], 403);
    }

    wp_send_json_success([
        'messages' => scp_chat_get_messages($room_id, 50, $after_id),
    ]);
});

function scp_chat_get_user_rooms($user_id) {
    global $wpdb;

    $rooms_table = scp_chat_table_rooms();
    $messages_table = scp_chat_table_messages();

    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT r.*, m.message AS last_message, m.created_at AS last_message_at
         FROM {$rooms_table} r
         LEFT JOIN {$messages_table} m ON m.id = (
            SELECT mm.id FROM {$messages_table} mm WHERE mm.room_id = r.id ORDER BY mm.id DESC LIMIT 1
         )
         WHERE r.user_one = %d OR r.user_two = %d
         ORDER BY r.updated_at DESC",
        (int) $user_id,
        (int) $user_id
    ));

    $rooms = [];
    foreach ($rows as $row) {
        $other_user_id = ((int) $row->user_one === (int) $user_id) ? (int) $row->user_two : (int) $row->user_one;
        $other_user = scp_chat_get_user_payload($other_user_id);
        if (!$other_user) {
            continue;
        }
        $rooms[] = [
            'room_id' => (int) $row->id,
            'other_user' => $other_user,
            'last_message' => $row->last_message ? wp_trim_words($row->last_message, 12, '...') : '',
            'updated_at' => mysql2date('c', $row->updated_at),
            'last_message_at' => $row->last_message_at ? mysql2date('c', $row->last_message_at) : null,
        ];
    }

    return $rooms;
}

add_action('wp_ajax_scp_chat_get_rooms', function () {
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'unauthorized'], 401);
    }
    scp_chat_nonce_or_fail();

    wp_send_json_success([
        'rooms' => scp_chat_get_user_rooms(get_current_user_id()),
    ]);
});

function scp_chat_widget_markup() {
    if (!is_user_logged_in()) {
        return;
    }
    ?>
    <div id="scp-chat-widget" class="scp-chat-widget" aria-live="polite"></div>
    <?php
}
add_action('wp_footer', 'scp_chat_widget_markup');

function scp_chat_rooms_shortcode() {
    if (!is_user_logged_in()) {
        return '<p class="scp-chat-login-note">برای مشاهده چت‌ها ابتدا وارد حساب خود شوید.</p>';
    }

    $rooms = scp_chat_get_user_rooms(get_current_user_id());

    ob_start();
    ?>
    <section class="scp-chat-page" id="scp-chat-page">
        <aside class="scp-chat-room-list-wrap">
            <h3>Chat Rooms</h3>
            <div class="scp-chat-room-list" data-scp-chat-room-list="1">
                <?php if (!empty($rooms)) : ?>
                    <?php foreach ($rooms as $room) : ?>
                        <button type="button" class="scp-room-item" data-room-id="<?php echo esc_attr((int) $room['room_id']); ?>" data-room-name="<?php echo esc_attr($room['other_user']['name']); ?>">
                            <span class="scp-avatar-presence-wrap" data-scp-site-user-id="<?php echo esc_attr((int) $room['other_user']['id']); ?>">
                                <img src="<?php echo esc_url($room['other_user']['avatar']); ?>" alt="<?php echo esc_attr($room['other_user']['name']); ?>">
                                <span class="scp-site-presence-dot offline" data-tooltip="آفلاین در سایت"></span>
                            </span>
                            <span>
                                <strong><?php echo esc_html($room['other_user']['name']); ?></strong>
                                <small><?php echo esc_html($room['last_message']); ?></small>
                            </span>
                        </button>
                    <?php endforeach; ?>
                <?php else : ?>
                    <p class="scp-chat-empty">هنوز چت‌رومی ندارید. از دکمه چت در کارت کاربران شروع کنید.</p>
                <?php endif; ?>
            </div>
        </aside>
        <div class="scp-chat-thread-wrap">
            <div class="scp-chat-thread-placeholder">برای شروع، یکی از چت‌روم‌ها را انتخاب کنید.</div>
            <div class="scp-chat-thread" data-scp-chat-thread="1" hidden></div>
            <form class="scp-chat-form" data-scp-chat-form="1" hidden>
                <input type="text" name="message" maxlength="1000" autocomplete="off" placeholder="پیام خود را بنویسید...">
                <button type="submit">ارسال</button>
            </form>
        </div>
    </section>
    <?php

    return ob_get_clean();
}
add_shortcode('steam_chat_rooms', 'scp_chat_rooms_shortcode');


function scp_get_private_profile_url() {
    return home_url('/profile/');
}

function scp_private_profile_top_shortcode() {
    if (!is_user_logged_in()) {
        $login_url = wp_login_url(scp_get_private_profile_url());
        return '<p class="scp-chat-login-note">برای مشاهده پروفایل شخصی ابتدا وارد حساب خود شوید. <a href="' . esc_url($login_url) . '">ورود</a></p>';
    }

    $user_id = get_current_user_id();
    $user = get_userdata($user_id);
    if (!$user) {
        return '<p class="scp-chat-empty">اطلاعات کاربر یافت نشد.</p>';
    }

    $steam_id = (string) get_user_meta($user_id, 'steam_id', true);
    $steam_data = $steam_id ? scp_get_steam_user_info($steam_id, true) : false;
    $avatar = ($steam_data && !empty($steam_data['avatar'])) ? esc_url_raw($steam_data['avatar']) : scp_get_user_avatar_url($user_id, 128);
    $public_profile_url = $steam_id ? home_url('/steam-user/' . $steam_id) : '';

    $steam_level = $steam_data ? intval($steam_data['level']) : 0;
    $level_class = 'scp-level-basic';
    if ($steam_level >= 11 && $steam_level <= 30) {
        $level_class = 'scp-level-bronze';
    } elseif ($steam_level >= 31 && $steam_level <= 60) {
        $level_class = 'scp-level-silver';
    } elseif ($steam_level >= 61 && $steam_level <= 100) {
        $level_class = 'scp-level-gold';
    } elseif ($steam_level >= 101) {
        $level_class = 'scp-level-platinum';
    }

    $steam_online = ($steam_data && isset($steam_data['online']) && intval($steam_data['online']) > 0);

    ob_start();
    ?>
    <section class="scp-public-profile scp-private-profile" id="scp-private-profile">
        <div class="scp-public-card-pro">
            <div class="scp-public-card-head">
                <span class="scp-avatar-presence-wrap" data-scp-site-user-id="<?php echo esc_attr((string) $user_id); ?>">
                    <img src="<?php echo esc_url($avatar); ?>" alt="<?php echo esc_attr($user->display_name); ?>">
                    <span class="scp-site-presence-dot offline" data-tooltip="آفلاین در سایت"></span>
                </span>
                <div class="scp-public-user-info">
                    <h2><?php echo esc_html($user->display_name); ?></h2>
                    <div class="scp-meta-row scp-meta-row-profile">
                        <?php if ($steam_data) : ?>
                            <span class="scp-level-badge <?php echo esc_attr($level_class); ?>" data-tooltip="<?php esc_attr_e('Steam Level', 'steam-connect-pro'); ?>">
                                <?php printf(esc_html__('Lv. %d', 'steam-connect-pro'), $steam_level); ?>
                            </span>
                        <?php endif; ?>
                        <span class="scp-online-status-profile <?php echo $steam_online ? 'online' : 'offline'; ?>" data-tooltip="in steam">
                            <?php echo $steam_online ? 'Online' : 'Offline'; ?>
                        </span>
                    </div>
                </div>
            </div>

            <div class="scp-public-actions">
                <?php if ($public_profile_url) : ?>
                    <a class="scp-profile-link-steami" href="<?php echo esc_url($public_profile_url); ?>">مشاهده پروفایل عمومی</a>
                <?php endif; ?>
                <a class="scp-profile-link-steami" href="<?php echo esc_url(wp_logout_url(home_url('/'))); ?>">خروج</a>
            </div>
        </div>
    </section>
    <?php

    return ob_get_clean();
}
add_shortcode('steam_private_profile', 'scp_private_profile_top_shortcode');

add_action('template_redirect', function () {
    $request_uri = isset($_SERVER['REQUEST_URI']) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : '';
    $path = wp_parse_url($request_uri, PHP_URL_PATH);
    $path = is_string($path) ? trailingslashit($path) : '';

    if ($path !== '/profile/') {
        return;
    }

    if (!is_user_logged_in()) {
        wp_safe_redirect(wp_login_url(scp_get_private_profile_url()));
        exit;
    }

    status_header(200);
    nocache_headers();

    get_header();
    echo do_shortcode('[steam_private_profile]');
    get_footer();
    exit;
}, 1);
